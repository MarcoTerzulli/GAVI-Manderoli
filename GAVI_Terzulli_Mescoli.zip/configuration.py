index_dir = "Wiki_index"
xml_file = "relevant_articles.xml"

# Test samples
relevant_pages = {}
